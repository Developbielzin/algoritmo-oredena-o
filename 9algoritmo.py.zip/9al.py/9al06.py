#counting sort
def counting_sort(lista):
    
    valor_maximo = max(lista)  
    count = [0] * (valor_maximo + 1)  

    
    for elemento in lista:
        count[elemento] += 1
    
    for i in range(1, valor_maximo + 1):
        count[i] += count[i - 1]

    
    
    size = len(lista)
    output = [0] * size
    for i in range(size - 1, -1, -1):
        output[count[lista[i]] - 1] = lista[i]
        count[lista[i]] -= 1

    
    for i in range(size):
        lista[i] = output[i]


lista = [4, 2, 2, 8, 3, 3, 1]
counting_sort(lista)
print("Lista ordenada:", lista)
