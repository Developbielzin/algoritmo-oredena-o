def bk (bucket):
    for i in range(1, len(bucket)):
        chave = bucket[i]
        j = i - 1
        while j >= 0 and bucket[j] > chave:
            bucket[j + 1] = bucket[j]
            j -= 1
        bucket[j + 1] = chave

def bucketSort(arr):
    n = len(arr)
    buckets = [[] for _ in range(n)]

    # Distribui os elementos nos buckets
    for i in range(n):
        index = int(n * arr[i])
        buckets[index].append(arr[i])

    # Ordena os elementos dentro de cada bucket
    for i in range(n):
        bk(buckets[i])

    # Reúne os elementos de todos os buckets
    result = []
    for i in range(n):
        result.extend(buckets[i])

    return result

# Exemplo de uso
lista = [0.78, 0.17, 0.39, 0.26, 0.72, 0.94, 0.21, 0.12, 0.23, 0.68]
ord_lista = bucketSort(lista)
print("Lista ordenada:", ord_lista)
