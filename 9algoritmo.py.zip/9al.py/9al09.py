def quicksort(lista, inicio=0, final=None):
    if final is None:
        final = len(lista)-1
    if inicio < final:
        p = partition(lista, inicio, final)
        
        quicksort(lista, inicio, p-1)
        
        quicksort(lista, p+1, final)





def partition(lista, inicio, fim):
    pivot = lista[fim]
    i = inicio
    for j in range(inicio, fim):
        
        if lista[j] <= pivot:
            lista[j], lista[i] = lista[i], lista[j]
            i = i + 1
    lista[i], lista[fim] = lista[fim], lista[i]
    return i
lista = [8, 4, 6, 2, 1, 12, 14]
quicksort(lista)
print('lista ordenada', lista)