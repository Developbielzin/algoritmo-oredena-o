def radi (lista, posição): 
    tamanho_lista = len(lista) 
    listan = [0] * tamanho_lista 
    count = [0] * 10 

    for i in range(0, tamanho_lista): 
        index = (lista[i]/posição) 
        count[int((index)%10)] += 1

    for i in range(1, 10): 
        count[i] += count[i-1] 

    i = tamanho_lista-1
    while i >= 0: 
        index = (lista[i]/posição) 
        listan[count[int((index)%10)] - 1] = lista[i] 
        count[int((index)%10)] -= 1
        i -= 1

    for i in range(len(lista)): 
        lista[i] = listan[i] 

def radixSort(lista):
    maximo1 = max(lista)
    posição = 1
    while maximo1 // posição > 0:
        radi(lista, posição)
        posição *= 10

# Driver code to test above
lista = [170, 45, 75, 90, 802, 24, 2, 66]
radixSort(lista)
print('Lista ordenada:', lista)
